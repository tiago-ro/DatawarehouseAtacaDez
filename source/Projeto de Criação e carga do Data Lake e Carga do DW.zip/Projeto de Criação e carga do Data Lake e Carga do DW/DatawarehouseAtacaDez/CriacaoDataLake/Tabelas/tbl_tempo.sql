﻿CREATE TABLE [dbo].[tbl_tempo]
(
	[cod_dia] VARCHAR(25) NOT NULL PRIMARY KEY, 
    [data] DATE NULL, 
    [controle] BIT NULL
)
